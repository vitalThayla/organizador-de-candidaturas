# Organizador de Candidaturas

Projeto pessoal de **Thayla Vital do Santos** — um aplicativo simples para organizar
candidaturas de emprego: em qual empresa se inscreveu, para qual vaga, em que data,
qual o status do processo e anotações de cada etapa.

## Por que esse projeto existe

- Acompanhar de verdade cada vaga: onde me inscrevi, o que aconteceu e o que falta fazer.
- Praticar os fundamentos da web: **HTML** (estrutura), **CSS** (aparência) e
  **JavaScript** (comportamento) — sem frameworks, para entender a base antes das ferramentas.
- Ter um projeto real e funcionando para mostrar no GitHub e demonstrar em entrevistas.

## Como funciona

1. Abra o arquivo `index.html` no navegador (basta dar dois cliques nele).
2. Preencha o formulário "Nova candidatura" e clique em **Salvar candidatura**.
3. Use os filtros para buscar por empresa/vaga, filtrar por status e ordenar a lista.
4. Cada card tem os botões **Editar** e **Apagar**.
5. Em "Cópia de segurança", é possível baixar os dados como **backup (.json)** ou
   **planilha (.csv, abre no Excel)** e restaurar um backup depois.

## Importante: onde os dados ficam

Os registros ficam salvos **somente no navegador daquele aparelho** (recurso chamado
`localStorage`). Isso significa:

- Não precisa de conta, senha ou internet — o app funciona 100% no seu computador.
- Se você limpar o histórico/dados do navegador, os registros **podem ser apagados**.
- Os dados não aparecem em outro aparelho. Para não perder nada, baixe o arquivo de
  backup de vez em quando (botão **Baixar backup**) e guarde-o.

## Tecnologias

- **HTML5** — estrutura da página (formulário, filtros, lista).
- **CSS3** — aparência, com variáveis de cor, sombras e layout responsivo (funciona no celular).
- **JavaScript (puro, sem bibliotecas)** — lógica de criar/editar/apagar (CRUD),
  filtros, ordenação, exportação de backup e CSV.

## Ideias para evoluir (próximos passos)

- Lembretes: destacar candidaturas há mais de X dias sem resposta.
- Histórico de etapas por candidatura (ex.: "enviei currículo" → "entrevista dia 12").
- Salvamento em nuvem (exige estudo de banco de dados — fase futura).
- Versão em React, para praticar componentes (fase futura).

## Como explicar este projeto em uma entrevista

- "Fiz um organizador de candidaturas em HTML, CSS e JavaScript puro, com dados salvos
  no `localStorage` do navegador."
- "Implementei o CRUD completo: criar, listar, filtrar, ordenar, editar e apagar registros."
- "Adicionei exportação de backup em JSON e planilha em CSV, com validação e confirmação
  antes de apagar ou restaurar."
- "Fiz proteção contra texto malicioso digitado pelo usuário (função que 'escapa' o HTML)."
