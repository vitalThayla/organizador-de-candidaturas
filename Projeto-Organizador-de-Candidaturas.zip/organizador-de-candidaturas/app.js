/* ============================================================
   Organizador de Candidaturas — lógica do aplicativo
   ------------------------------------------------------------
   Como funciona (resumo para estudar):
   1. Os dados ficam guardados no "localStorage" — uma pequena
      memória que o próprio navegador oferece a cada site.
   2. Toda vez que algo muda, a lista inteira é redesenhada
      na tela a partir dos dados (isso se chama "renderizar").
   3. Nada vai para a internet: o app funciona 100% no seu
      computador/celular, sem conta e sem servidor.
   ============================================================ */

// ---------- Constantes e estado ----------
const CHAVE_DADOS = "organizador-candidaturas-v1"; // nome usado no localStorage

let candidaturas = carregar(); // lista salva no navegador
let filtros = { busca: "", status: "Todas", ordem: "recentes" };
let idEmEdicao = null; // quando não é null, o formulário está editando uma candidatura

// ---------- Referências aos elementos da tela ----------
const el = {
  formulario: document.getElementById("formulario"),
  campoId: document.getElementById("campo-id"),
  campoEmpresa: document.getElementById("campo-empresa"),
  campoVaga: document.getElementById("campo-vaga"),
  campoData: document.getElementById("campo-data"),
  campoStatus: document.getElementById("campo-status"),
  campoCanal: document.getElementById("campo-canal"),
  campoContato: document.getElementById("campo-contato"),
  campoLink: document.getElementById("campo-link"),
  campoAnotacoes: document.getElementById("campo-anotacoes"),
  tituloFormulario: document.getElementById("titulo-formulario"),
  botaoSalvar: document.getElementById("botao-salvar"),
  botaoCancelarEdicao: document.getElementById("botao-cancelar-edicao"),
  filtroBusca: document.getElementById("filtro-busca"),
  filtroStatus: document.getElementById("filtro-status"),
  filtroOrdem: document.getElementById("filtro-ordem"),
  listaCards: document.getElementById("lista-cards"),
  listaVazia: document.getElementById("lista-vazia"),
  listaSemFiltro: document.getElementById("lista-sem-filtro"),
  resumoTotal: document.getElementById("resumo-total"),
  resumoAtivas: document.getElementById("resumo-ativas"),
  resumoPropostas: document.getElementById("resumo-propostas"),
  resumoRecusadas: document.getElementById("resumo-recusadas"),
  botaoBackup: document.getElementById("botao-backup"),
  botaoPlanilha: document.getElementById("botao-planilha"),
  campoRestaurar: document.getElementById("campo-restaurar"),
};

// ============================================================
// 1. GUARDAR E LER OS DADOS (localStorage)
// ============================================================

// Lê a lista salva no navegador. Se não existir ou estiver
// corrompida, devolve uma lista vazia (app continua funcionando).
function carregar() {
  try {
    const salvo = localStorage.getItem(CHAVE_DADOS);
    return salvo ? JSON.parse(salvo) : [];
  } catch {
    return [];
  }
}

// Salva a lista inteira no navegador, como texto JSON.
function salvar() {
  localStorage.setItem(CHAVE_DADOS, JSON.stringify(candidaturas));
}

// ============================================================
// 2. CRIAR, EDITAR E APAGAR (o "CRUD")
//    C = Create, R = Read, U = Update, D = Delete
// ============================================================

// Chamado quando o formulário é enviado.
el.formulario.addEventListener("submit", function (evento) {
  evento.preventDefault(); // impede a página de recarregar

  const dados = {
    empresa: el.campoEmpresa.value.trim(),
    vaga: el.campoVaga.value.trim(),
    data: el.campoData.value,
    status: el.campoStatus.value,
    canal: el.campoCanal.value,
    contato: el.campoContato.value.trim(),
    link: el.campoLink.value.trim(),
    anotacoes: el.campoAnotacoes.value.trim(),
  };

  if (idEmEdicao) {
    // UPDATE: acha a candidatura pelo id e substitui os campos
    const existente = candidaturas.find(function (c) {
      return c.id === idEmEdicao;
    });
    if (existente) Object.assign(existente, dados);
    sairDoModoEdicao();
  } else {
    // CREATE: cria um id único e coloca a nova candidatura no começo da lista
    candidaturas.unshift({ id: gerarId(), criadoEm: new Date().toISOString(), ...dados });
  }

  salvar();
  renderizarTudo();
  el.formulario.reset();
});

// Gera um id simples: número aleatório + hora atual, em texto.
function gerarId() {
  return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// DELETE: pede confirmação antes de apagar.
function apagarCandidatura(id) {
  const item = candidaturas.find(function (c) {
    return c.id === id;
  });
  if (!item) return;
  const confirmou = confirm("Apagar a candidatura de " + item.empresa + " — " + item.vaga + "?");
  if (!confirmou) return;

  candidaturas = candidaturas.filter(function (c) {
    return c.id !== id;
  });
  salvar();
  renderizarTudo();
}

// EDIT: carrega os dados da candidatura no formulário.
function editarCandidatura(id) {
  const item = candidaturas.find(function (c) {
    return c.id === id;
  });
  if (!item) return;

  idEmEdicao = id;
  el.campoEmpresa.value = item.empresa;
  el.campoVaga.value = item.vaga;
  el.campoData.value = item.data || "";
  el.campoStatus.value = item.status || "Inscrita";
  el.campoCanal.value = item.canal || "";
  el.campoContato.value = item.contato || "";
  el.campoLink.value = item.link || "";
  el.campoAnotacoes.value = item.anotacoes || "";

  el.tituloFormulario.textContent = "Editando: " + item.empresa;
  el.botaoSalvar.textContent = "Salvar alterações";
  el.botaoCancelarEdicao.hidden = false;
  el.formulario.scrollIntoView({ behavior: "smooth", block: "start" });
  el.campoEmpresa.focus();
}

// Sai do modo edição e volta o formulário para "nova candidatura".
function sairDoModoEdicao() {
  idEmEdicao = null;
  el.tituloFormulario.textContent = "Nova candidatura";
  el.botaoSalvar.textContent = "Salvar candidatura";
  el.botaoCancelarEdicao.hidden = true;
}

el.botaoCancelarEdicao.addEventListener("click", function () {
  sairDoModoEdicao();
  el.formulario.reset();
});

// ============================================================
// 3. FILTROS E ORDENAÇÃO
// ============================================================

el.filtroBusca.addEventListener("input", function () {
  filtros.busca = el.filtroBusca.value.trim().toLowerCase();
  renderizarLista();
});

el.filtroStatus.addEventListener("change", function () {
  filtros.status = el.filtroStatus.value;
  renderizarLista();
});

el.filtroOrdem.addEventListener("change", function () {
  filtros.ordem = el.filtroOrdem.value;
  renderizarLista();
});

// Devolve apenas as candidaturas que passam pelos filtros,
// já na ordem escolhida. A lista original não é alterada.
function candidaturasVisiveis() {
  let lista = candidaturas.filter(function (c) {
    const noStatus = filtros.status === "Todas" || c.status === filtros.status;
    const texto = (c.empresa + " " + c.vaga).toLowerCase();
    const naBusca = texto.indexOf(filtros.busca) !== -1;
    return noStatus && naBusca;
  });

  if (filtros.ordem === "empresa") {
    lista = lista.slice().sort(function (a, b) {
      return a.empresa.localeCompare(b.empresa, "pt-BR");
    });
  } else {
    // datas em formato "2026-10-23" se comparam bem como texto
    lista = lista.slice().sort(function (a, b) {
      const da = a.data || "";
      const db = b.data || "";
      if (da === db) return 0;
      return filtros.ordem === "recentes" ? (da < db ? 1 : -1) : da < db ? -1 : 1;
    });
  }
  return lista;
}

// ============================================================
// 4. RENDERIZAR (desenhar a tela com base nos dados)
// ============================================================

function renderizarTudo() {
  renderizarResumo();
  renderizarLista();
}

function renderizarResumo() {
  el.resumoTotal.textContent = candidaturas.length;
  el.resumoAtivas.textContent = candidaturas.filter(function (c) {
    return c.status === "Inscrita" || c.status === "Entrevista" || c.status === "Teste";
  }).length;
  el.resumoPropostas.textContent = candidaturas.filter(function (c) {
    return c.status === "Proposta";
  }).length;
  el.resumoRecusadas.textContent = candidaturas.filter(function (c) {
    return c.status === "Recusada" || c.status === "Desistiu";
  }).length;
}

function renderizarLista() {
  const lista = candidaturasVisiveis();

  el.listaVazia.hidden = candidaturas.length !== 0;
  el.listaSemFiltro.hidden = !(candidaturas.length !== 0 && lista.length === 0);

  // innerHTML recebe o HTML pronto de cada card (montado como texto)
  el.listaCards.innerHTML = lista.map(montarCard).join("");
}

// Monta o HTML de um card. Cada botão chama a função global
// correspondente passando o id (por isso usamos window.*).
function montarCard(c) {
  const pedacos = [];

  pedacos.push('<article class="cartao-candidatura">');
  pedacos.push('  <div class="cartao-cabecalho">');
  pedacos.push('    <div>');
  pedacos.push('      <h3 class="cartao-empresa">' + escapar(c.empresa) + "</h3>");
  pedacos.push('      <p class="cartao-vaga">' + escapar(c.vaga) + "</p>");
  pedacos.push("    </div>");
  pedacos.push("  </div>");

  pedacos.push('  <div class="cartao-info">');
  pedacos.push('    <span class="etiqueta etiqueta-' + escapar(c.status) + '">' + escapar(c.status) + "</span>");
  if (c.data) pedacos.push('    <span class="etiqueta etiqueta-neutra">' + formatarData(c.data) + "</span>");
  if (c.canal) pedacos.push('    <span class="etiqueta etiqueta-neutra">Via ' + escapar(c.canal) + "</span>");
  if (c.contato) pedacos.push('    <span class="etiqueta etiqueta-neutra">' + escapar(c.contato) + "</span>");
  pedacos.push("  </div>");

  if (c.link) {
    pedacos.push(
      '  <p class="cartao-vaga" style="margin-top:0.6rem"><a href="' +
        escapar(c.link) +
        '" target="_blank" rel="noopener">Ver anúncio da vaga ↗</a></p>'
    );
  }
  if (c.anotacoes) {
    pedacos.push('  <p class="cartao-anotacoes">' + escapar(c.anotacoes) + "</p>");
  }

  pedacos.push('  <div class="cartao-acoes">');
  pedacos.push(
    '    <button class="botao-pequeno" onclick="editarCandidatura(\'' + c.id + '\')">Editar</button>'
  );
  pedacos.push(
    '    <button class="botao-pequeno" onclick="apagarCandidatura(\'' + c.id + '\')">Apagar</button>'
  );
  pedacos.push("  </div>");
  pedacos.push("</article>");

  return pedacos.join("\n");
}

// Transforma "2026-10-23" em "23/10/2026".
function formatarData(dataISO) {
  const pedacos = dataISO.split("-");
  if (pedacos.length !== 3) return dataISO;
  return pedacos[2] + "/" + pedacos[1] + "/" + pedacos[0];
}

// Proteção básica: troca os caracteres especiais do HTML para que
// um texto digitado pela usuária não seja confundido com código.
function escapar(texto) {
  return String(texto)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// As funções de editar/apagar são chamadas pelos botões dos cards,
// então precisam existir "globalmente" (acessíveis pelo HTML gerado).
window.editarCandidatura = editarCandidatura;
window.apagarCandidatura = apagarCandidatura;

// ============================================================
// 5. BACKUP: exportar (JSON e CSV) e restaurar (JSON)
// ============================================================

// Dispara o download de um arquivo gerado aqui mesmo.
function baixarArquivo(nome, conteudo, tipo) {
  const bolha = new Blob([conteudo], { type: tipo });
  const endereco = URL.createObjectURL(bolha);
  const link = document.createElement("a");
  link.href = endereco;
  link.download = nome;
  link.click();
  URL.revokeObjectURL(endereco);
}

el.botaoBackup.addEventListener("click", function () {
  const hoje = new Date().toISOString().slice(0, 10);
  baixarArquivo(
    "backup-candidaturas-" + hoje + ".json",
    JSON.stringify(candidaturas, null, 2),
    "application/json"
  );
});

// CSV = formato que o Excel abre direto. Campos com vírgula ou
// aspas são envolvidos em aspas (e aspas internas são dobradas).
el.botaoPlanilha.addEventListener("click", function () {
  const cabecalho = ["Empresa", "Vaga", "Data", "Status", "Onde se inscreveu", "Contato", "Link", "Anotações"];
  const linhas = candidaturas.map(function (c) {
    return [c.empresa, c.vaga, c.data, c.status, c.canal, c.contato, c.link, c.anotacoes]
      .map(campoCsv)
      .join(",");
  });
  const csv = [cabecalho.map(campoCsv).join(","), ...linhas].join("\n");
  const hoje = new Date().toISOString().slice(0, 10);
  baixarArquivo("candidaturas-" + hoje + ".csv", "\ufeff" + csv, "text/csv;charset=utf-8");
});

function campoCsv(valor) {
  const texto = String(valor ?? "");
  if (texto.includes(",") || texto.includes('"') || texto.includes("\n")) {
    return '"' + texto.replaceAll('"', '""') + '"';
  }
  return texto;
}

// Restaurar: o usuário escolhe um arquivo .json e ele substitui os dados atuais.
el.campoRestaurar.addEventListener("change", function () {
  const arquivo = el.campoRestaurar.files[0];
  if (!arquivo) return;

  const leitor = new FileReader();
  leitor.onload = function () {
    try {
      const dados = JSON.parse(leitor.result);
      if (!Array.isArray(dados)) throw new Error("formato");
      const confirmou = confirm(
        "Isso vai substituir as " + candidaturas.length + " candidaturas atuais pelas " + dados.length + " do arquivo. Continuar?"
      );
      if (!confirmou) return;
      candidaturas = dados;
      salvar();
      renderizarTudo();
    } catch {
      alert("Não consegui ler esse arquivo. Use um backup gerado pelo próprio app (.json).");
    }
  };
  leitor.readAsText(arquivo);
  el.campoRestaurar.value = ""; // permite escolher o mesmo arquivo de novo
});

// ============================================================
// 6. INÍCIO: quando a página abre, data de hoje pré-preenchida
//    e a tela desenhada com os dados salvos.
// ============================================================
el.campoData.value = new Date().toISOString().slice(0, 10);
renderizarTudo();
